﻿########################################################################################################################################
# Nicolas BONNET - Avril 2021                                                                                                                       #
# Importation des comptes Active Directory                                                                                             #
########################################################################################################################################

#Création des unités d'organisation
New-ADOrganizationalUnit -Name "Formation" -Path "DC=Training,DC=Priv"
New-ADOrganizationalUnit -Name "Groupes" -Path "OU=Formation,DC=Training,DC=Priv"
New-ADOrganizationalUnit -Name "Utilisateurs" -Path "OU=Formation,DC=Training,DC=Priv"
New-ADOrganizationalUnit -Name "Ordinateur" -Path "OU=Formation,DC=Training,DC=Priv"

#Le mot de passe des utilisateurs est ajouté dans une variable
$mdp = "L@vreEnhiV##m"

#Le mot de passe contenu dans la variable est chiffré
$mdps = ConvertTo-SecureString -String $mdp -AsPlainText -Force

#The contents of the csv file is added to a variable
$users = Import-Csv -Path 'C:\temp\account.csv' -Delimiter ";"

#For each line in the variable, a user is created in the organizational unit (the path is given in the script). 
#Properties configured for the new account are: DisplayName, ACCOUNTPASSWORD, City, compagny, title, GivenName, Surname,	UserPrincipalName ,OfficePhone,SamAcountName
foreach ($u in $users)
{New-ADUser -name $u.DisplayName -Path "OU=Utilisateurs,OU=Formation,DC=Training,DC=Priv" -DisplayName $u.Displayname -AccountPassword $mdps -City $u.ville -Company $u.societe -Department $u.service -Title $u.fonction -GivenName $u.prenom -Surname $u.nom -UserPrincipalName $u.upn -OfficePhone $u.telephone -SamAccountName $u.compte -enable $true }
